# soccerproject > 2024-12-20 9:57am
https://universe.roboflow.com/assignmentlabelws/soccerproject-qw7d9

Provided by a Roboflow user
License: CC BY 4.0

